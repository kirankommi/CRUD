﻿using System;
using System.Collections.Generic;
using api.Models;

namespace api.Repository
{
    public interface IEmployeeRepository
    {
        IList<Employee> GetEmployees();

        void AddEmployee(Employee emp);

        void UpdateEmployee(Employee emp);

        void DeleteEmployee(int id);

        Employee getEmployeeById(int id);
    }
}
