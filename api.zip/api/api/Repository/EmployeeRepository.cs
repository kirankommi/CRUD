﻿using System;
using System.Collections.Generic;
using System.Linq;
using api.Models;

namespace api.Repository
{
    public class EmployeeRepository: IEmployeeRepository
    {
        public EmployeeRepository()
        {
              
        }

        public IList<Employee> GetEmployees()
        {
            try
            {
                IList<Employee> employees = null;

                using (var ctx = new testContext())
                {
                    employees = ctx.Employees.ToList();
                }

                return employees;
            }
            catch(Exception e)
            {

            }
            

        }

        public void AddEmployee(Employee emp)
        {
            using (var context = new testContext())
            {
                var std = new Employee()
                {
                    Name = emp.Name
                };
                context.Employees.Add(std);
                context.SaveChanges();
            }
        }

        public void UpdateEmployee(Employee emp)
        {
            using (var ctx = new testContext())
            {
                var existingEmployee = ctx.Employees.Where(s => s.Id == emp.Id)
                                                        .FirstOrDefault<Employee>();

                if (existingEmployee != null)
                {
                    existingEmployee.Name = emp.Name;

                    ctx.SaveChanges();
                }
            }
        }

        public void DeleteEmployee(int id)
        {
            //var empid = Convert.ToInt16(id);
            using (var ctx = new testContext())
            {
                var emp = ctx.Employees
                    .Where(s => s.Id == id)
                    .FirstOrDefault();

                ctx.Employees.Remove(emp);
                ctx.SaveChanges();
            }
        }

        public Employee getEmployeeById(int id)
        {
            using (var ctx = new testContext())
            {

                return ctx.Employees.Where(s => s.Id == id)
                                                        .FirstOrDefault<Employee>();
            }
        }
    }
}
