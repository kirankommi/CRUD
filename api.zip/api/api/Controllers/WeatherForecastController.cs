﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Web;
using System.Data;
using api.Repository;

namespace api.Controllers
{
    [ApiController]
    [Route("[controller]/")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IEmployeeRepository _employeeRepository;

        public WeatherForecastController(ILogger<WeatherForecastController> logger,
            IEmployeeRepository employeeRepository)
        {
            _logger = logger;
            _employeeRepository = employeeRepository;
        }

        [HttpGet]
        [Route("GetEmployees")]
        public IActionResult GetEmployees()
        {
            IList<Employee> employees = null;
            employees = _employeeRepository.GetEmployees();

            if (employees.Count == 0)
            {
                return NotFound();
            }

            return Ok(employees);

        }

        [HttpPost]
        [Route("AddEmployee")]
        public IActionResult AddEmployee([FromBody] Employee emp) 
        {
            _employeeRepository.AddEmployee(emp);
            return Ok();
        }

        [HttpPut]
        [Route("UpdateEmployee")]
        public void UpdateEmployee([FromBody] Employee emp)
        {
            _employeeRepository.UpdateEmployee(emp);
        }

        [HttpDelete]
        [Route("DeleteEmployee/{id:int}")]
        public void DeleteEmployee(int id)
        {


            _employeeRepository.DeleteEmployee(id);
        }

        [HttpGet]
        [Route("getEmployeeById/{id:int}")]
        public Employee getEmployeeById(int id)
        {
            return _employeeRepository.getEmployeeById(id);
        }
    }
}
