﻿using System;
using System.Collections.Generic;

#nullable disable

namespace api.Models
{
    public partial class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
