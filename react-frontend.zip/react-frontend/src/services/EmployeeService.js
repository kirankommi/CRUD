import axios from 'axios';

const EMPLOYEE_API_BASE_URL = "http://localhost:5000/WeatherForecast";

class EmployeeService {

    getEmployees(){
        return axios.get(EMPLOYEE_API_BASE_URL+ '/' + 'GetEmployees');
    }

    createEmployee(employee){
        return axios.post(EMPLOYEE_API_BASE_URL+ '/' + 'AddEmployee', employee);
    }

    getEmployeeById(employeeId){
        return axios.get(EMPLOYEE_API_BASE_URL+ '/' + 'getEmployeeById' + '/' + employeeId);
    }

    updateEmployee(employee, employeeId){
        return axios.put(EMPLOYEE_API_BASE_URL + '/' + 'UpdateEmployee', employee);
    }

    deleteEmployee(employeeId){
        return axios.delete(EMPLOYEE_API_BASE_URL+ '/' + 'deleteEmployee' + '/' + employeeId);
    }
}

export default new EmployeeService()